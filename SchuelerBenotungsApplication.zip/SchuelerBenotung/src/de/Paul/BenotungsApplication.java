package de.Paul;
/**
 *
 * @author Paul Storch It 19/6 Gr. 2
 */

import de.Paul.Input.MainMenuOptions;

public class BenotungsApplication {



    public static void main(String[] args) {

        System.out.println("\n\n Welcome to the Schoolbook application!\n\n" +
                           "------------------------------------------");

        MainMenuOptions.options();


        }
    }
