package de.Paul.Components;

import java.rmi.server.UID;

public class UniqueId {

 public static int userId;

    public static void uniqueIdCreator() {

        for (int id = 0; id < 100; ++id) {
            UID userId = new UID();

        };
    }
}

