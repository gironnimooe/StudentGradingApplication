package de.Paul.Components;

public class clearCls {

    public static void clear() {
    for(int clear = 0; clear < 500; clear++)
    {
        System.out.println("\b") ;
    }
    }
}
