package de.Paul.Input;


import de.Paul.PersonsAndObjects.Subjects;

public class ClassBookMenu {

    static public void myTestVoid() {
        System.out.println("keys " + Subjects.key);
        System.out.println("value " + Subjects.value);
    }
}
