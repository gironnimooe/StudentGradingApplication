package de.Paul.Input;

import de.Paul.PersonsAndObjects.Student;

import java.util.Scanner;


public class GradeBookMenu {

    /** Public variables */
    public static String option1, option2, option3 = "";

    /** Method */
    public static void gradeBookOptions() {

        /** Private Variable */
        String order = "";
        int choice = 0;

        Scanner menuScan = new Scanner(System.in);
        System.out.println("---------- Gradebook ----------\n");

        option1 = ".....[1] Edit student";
        option2 = ".....[2] Create student";
        option3 = ".....[3] Back to menu\n";

        System.out.println(option1);
        System.out.println(option2);
        System.out.println(option3);

        /** Logic + Output */

        switch (choice = menuScan.nextInt()) {
            case 1:
                order = option1;
                System.out.println("\nYou have chosen " + order + " ! \n\n");
                Student.editStudent();
                break;
            case 2:
                order = option2;
                System.out.println("\nYou have chosen " + order + " ! \n");
                Student.newStudent();
                GradeBookMenu.gradeBookOptions();
                break;
            case 3:
                order = option3;
                System.out.println("You have left the Gradebook!");
                MainMenuOptions.options();
                break;
            default:
                System.out.println("Invalid selection. Please try again!");
                GradeBookMenu.gradeBookOptions();

        }



    }
}
