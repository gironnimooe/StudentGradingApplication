package de.Paul.Input;

import java.util.Scanner;

public class MainMenuOptions {

    /** Public vriable */
    public static final String[] option = new String[4];

    /** Methode um das Optionsmenu darzustellen */
    public static void options() {

        /** Private Variable */
        String order = "";
        int choice = 0;

        /** Input */
        Scanner menuScan = new Scanner(System.in);
        System.out.println("Please choose on of the following Options\n" +
                           "------------------------------------------\n");
        option[1] = ".....[1] Show gradebook";
        option[2] = ".....[2] Show classbook";
        option[3] = ".....[3] Exit the application\n";

        System.out.println(option[1]);
        System.out.println(option[2]);
        System.out.println(option[3]);


        /** Logic + Output */
        switch (choice = menuScan.nextInt()) {
            case 1:
                order = option[1];
                System.out.println("\nYou have chosen " + order + " ! \n");
                GradeBookMenu.gradeBookOptions();
                break;
            case 2:
                order = option[2];
                System.out.println("\nYou have chosen " + order + " ! \n");
                System.out.println("\n!!! This option is currently not available. Please try again !!!\n\n\n");
                ClassBookMenu.myTestVoid();
                break;
            case 3:
                System.out.println( "| -------------------- |\n" +
                                    "|       Goodbye!       |" +
                                    "| Hope to see you soon!|n"+
                                    "| ____________________ |");
                break;
            default:
                System.out.println("No option selected. Please try again!\n");
                MainMenuOptions.options();


        }

    }

}
