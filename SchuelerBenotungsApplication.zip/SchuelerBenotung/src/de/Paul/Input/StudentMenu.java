package de.Paul.Input;

public class StudentMenu {


    public static void editGrade() {

    }
}
