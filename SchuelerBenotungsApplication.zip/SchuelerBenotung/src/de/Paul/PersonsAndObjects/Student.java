package de.Paul.PersonsAndObjects;


import de.Paul.PersonsAndObjects.Subjects;
import de.Paul.Input.GradeBookMenu;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;


public class Student {
    /** Public variables */
    public static String s_lastName;
    public static String s_firstName;
    public static int s_grades = 0;
    public static String s_subjects = "";

    /** Initialize a HashMap with 2 Strings as parameter */
    public static final Map<Integer, String> studentList = new HashMap<>();

    /** Method to create a new Student */
    public static void newStudent() {

        System.out.println("---------- Create Student ----------\n");
        Scanner sc = new Scanner(System.in);


        System.out.println("Please type in the first name of you'r student: ");
        s_firstName = sc.nextLine();
        if (Student.s_firstName.equals("") || s_firstName.length() == 0) {
            System.out.println("The textfield has no content, please fill out the field by using Letters without special characters only");
            throw new IllegalArgumentException();
        }




        studentList.put(studentList.size() + 1," " + s_lastName + ", " + s_firstName);

        System.out.println("Student " + s_firstName + " " + s_lastName + " with id: "+ " was created successfully.\n");
    }

    /** Methode zum bearbeiten eines Schülers */
    public static void editStudent() {

        int chosen = 0;
        Scanner editScan = new Scanner(System.in);

        if (studentList.isEmpty()) {
            System.out.println("\b\n--------------------------------------------------\n" +
                               "Nothing is saved yet. Please create a new student!\n" +
                               "__________________________________________________\n\n");
            GradeBookMenu.gradeBookOptions();
        } else {

            System.out.println("Please select a student from the list" +
                               "Studentname: ");
            printList();
            chosen = editScan.nextInt();
            if (studentList.containsKey(chosen)) {
                String student = studentList.get(chosen);
                System.out.println("-------------------------------");
                System.out.println("|\tId  : " + chosen +
                                   "\n|\tName: " + s_firstName + " " + s_lastName);
                System.out.println("-------------------------------");
                Subjects.subjectDataList();
            }
            else {
                System.out.println("The selected student-id is not in the list. Please try again!\n\n");
                editStudent();
            }
        }
    }
    /** Methode zum ausgeben der Liste */
    public static void printList() {

        for (int i : studentList.keySet()) {
            System.out.println( i + studentList.get(i));
        }
    }

    public static void selectedStudent() {


    }

    public static void deleteStudent() {

    }
}


        /*System.out.println("Please choose the subject you want to grade");
        Schueler.s_Unterrichtsfach = sc.nextLine();
        if (Schueler.s_name.equals("")) {
            System.out.println("Es muss ein Unterrichtsfach angegeben werden! Bitte benutzen sie Buchstaben ohne Sonderzeichen");
            throw new IllegalArgumentException ();
        }

        System.out.println("Bitte tragen sie eine Note ein: ");
        Schueler.s_note = sc.nextInt();
        if (Schueler.s_note == 0) {
            System.out.println("Es muss ein Note eingetragen werden! Bitte benutzen sie nur Ganzzahlen ohne Sonderzeichen");
            throw new IllegalArgumentException ();
        }*/




