package de.Paul.PersonsAndObjects;

import de.Paul.Input.GradeBookMenu;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Subjects {

    /** Variables */
    public static int sub_Id;
    public static String sub_Name;
    public static String sub_Teacher;
    public static String newGrade;
    public static int choice;
    public static int key;
    public static int chosenKey;
    public static String value;
    public static int convGrade;

    /** Initialize a HashMap with int "Key" and String "Value" */
    public static final Map<Integer, String> subjectList = new HashMap<>();


    /** Construktor */
    public Subjects(int sub_Id, String sub_name, String teacher, String sub_grades) {
        sub_Name = sub_name;
        newGrade = sub_grades;
        Subjects.sub_Id = sub_Id;
        sub_Teacher = teacher;
    }


    public static void subjectDataList() {

        subjectList.put(1," FE   \t Fr. Luenser          " + "| Note: " );
        subjectList.put(2," EA/6 \t Grp.1 Hr. Schneemann " + "| Note: " );
        subjectList.put(3," EA/6 \t Grp.2 Dr. Bishof     " + "| Note: " );
        subjectList.put(4," EA/5 \t Grp.1 Hr. Schneemann " + "| Note: " );
        subjectList.put(5," EA/5 \t Grp.2 Hr. Schmidtke  " + "| Note: " );
        subjectList.put(6," BW/5 \t Hr. Lohrke           " + "| Note: " );
        subjectList.put(7," GK   \t Fr. Wittmann         " + "| Note: " );
        subjectList.put(8," DE   \t Fr. Kretzschmar      " + "| Note: " );
        subjectList.put(9," BW/6 \t Fr. Häußer           " + "| Note: " );
        subjectList.put(10,"IT/9\t Hr. Sebastian        " + "| Note: "  );
        subjectList.put(11,"BW/4\t Fr. Eckey            " + "| Note: "  );
        subjectList.put(12,"SP  \t Hr. Zangrando        " + "| Note: "  );
        subjectList.put(13,"IT/6\t Hr. Jungnickel       " + "| Note: "  );
        subjectList.put(14,"EA/7\t Hr. Baumann          " + "| Note: "  );
        subjectList.put(15,"IT/6\t Hr. Gutschke         " + "| Note: "  );
        subjectList.put(16,"IT/7\t Hr. Könnecke         " + "| Note: "  );
        System.out.println(17 + ": EA/4\t Hr. Schneemann       " + "| Note: ");
        System.out.println(18 + ": EA/1\t Fr. Neustadt         " + "| Note: ");

        printSubjectDataList();
        userChoice();
        getKeyAndValue();

        if (subjectList.containsKey(key) ){

            editGrades();
            subjectList.replace(chosenKey, value + convGrade);
            getKeyAndValue();
            printSubjectDataList();
            System.out.println("\nChoose your next step.\n");

        }
        GradeBookMenu.gradeBookOptions();
    }


    public static void printSubjectDataList() {

        subjectList.entrySet().forEach(entry -> {
            System.out.println(entry.getKey() + ": " + entry.getValue());teacher
        });
    }

    public static void getKeyAndValue() {
        for (final Map.Entry<Integer, String> entry : subjectList.entrySet()) {
            key = entry.getKey();
            value = entry.getValue();
        }
    }

    public static void userChoice() {
        Scanner subjectScan = new Scanner(System.in);
        System.out.println("Please choose one of the subjects by ID to set or change the grade.");
        choice = subjectScan.nextInt();
        chosenKey = choice;
        }

    public static void editGrades(){
        String valuePointer = subjectList.get(choice);
        Scanner gradeScan = new Scanner(System.in);
        System.out.println("\n\nPlease enter a new Grade for the chosen subject.\n" + valuePointer);
        System.out.println("Grade: ");
        newGrade = gradeScan.nextLine();
        convGrade = Integer.parseInt(newGrade);

    }
}




