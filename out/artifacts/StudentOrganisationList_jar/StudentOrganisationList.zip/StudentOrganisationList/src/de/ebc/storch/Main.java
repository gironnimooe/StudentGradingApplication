package de.ebc.storch;

import de.ebc.storch.inputOutput.Organisator;

public class Main {

    /** Einstiegspunkt */
    public static void main(String[] args) {

        Organisator org = new Organisator();
        org.start();
    }
}
